# Waruk Laundry

Warunk Laundry adalah sistem informasi pelayanan jasa laundry berbasis web.

## Instalasi

Gunakakan [git clone](https://pip.pypa.io/en/stable/) untuk menginstal aplikasi pada folder htdocs/folder root web server :

```bash
git clone https://github.com/TridentProject/warunk-laundry.git
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
